# chrome-watch
This extension displays how much time is spend on various websites in a day.

It will show you the top 7 stires where you spend your times, sorted in
descending order.
